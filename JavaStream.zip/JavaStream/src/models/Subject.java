package models;

public enum Subject {
    JAVA,
    ANDROID,
    BLOCKCHAIN,
    TIZEN,
    J2ME,
    FLUTTER,
    IOS,
    PTM,
    UNITY
}

